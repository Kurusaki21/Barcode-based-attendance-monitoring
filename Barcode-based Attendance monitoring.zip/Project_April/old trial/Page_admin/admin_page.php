<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring Website</title>
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon"/>
    <link rel="stylesheet" href="../Page_admin/css/index.css"/>

</head>

<body> 
    <header>
        <div class="top">
            <a href="#"><img src="../img/logo.png" /></a>
            <h2 class="logo">PBAMS</h2></a>
        </div>
        <div class="nav">
            <ul>
                <li><a href="../Page_admin/about.php">About</a></li>
                <li><a href="../Page_admin/contacts.php">Contacts</a></li>
                <li><a href="../login/logout.php">Log&nbsp;out</a></li>
            </ul>
        </div>
</header>

    <div class="side-menu">
        <div class="brand-name"></div>
            <nav><i><img src="../img/Profile.png"></i>
                <h2>Admin Name</h2>
                <p>ADMIN</p> 
            
                <ul>
                    <li><img src="../img/graph.png"><a href="index.php"><u>&nbsp;Dashboard</u></li></a>
                    <li><img src="../img/group.svg"> <a href="student.php">&nbsp;Students</li></a>
                    <li><img src="../img/records.png"><a href="#">&nbsp;Records</li></a>
                    <li><img src="../img/barcode.png"><a href="barcode.php">&nbsp;Barcode</li></a>
                    <li><img src="../img/sms.png"><a href="#">&nbsp;Messages</li> </a>
                </ul>
            </nav>

    <div class="card">
        <h1>Dashboard</h1>
        <div class="Students">
            <div class="group">
                <img src="../img/group.svg" />
                <p>Students</p>
                <h5>124</h5>
            <div class="all_Students">
                <h6><a href="#"><img src="../img/eye-solid.svg">Show all</h6></a>
            </div>
            </div>
        </div>

        <div class="present">
            <div class="profile">
                <img src="../img/user-solid.svg" />
                <p>Present</p>
                <h5>100</h5>
            <div class="all_Present">
                <h6><a href="#"><img src="../img/eye-solid.svg">Show all</h6></a>
            </div>
            </div>
        </div>
        
        <div class="absent">
            <div class="thumbs">
                <img src="../img/thumbs-down-solid.svg" />
                <p>Absent</p>
                <h5>12</h5>
            <div class="all_Absent">
                <h6><a href="#"><img src="../img/eye-solid.svg">Show all</h6></a>
            </div>
            </div>
        </div>

        <div class="late">
            <div class="clock">
                <img src="../img/clock-solid.svg" />
                <p>Late&nbsp;comers</p>
                <h5>12</h5>
            <div class="all_Late">
                <h6><a href="#"><img src="../img/eye-solid.svg">Show all</h6></a>
            </div>
            </div>
        </div>

        <div class="graph">
            <div class="clock">
                <img src="../img/pie.png" />
                <p>Absentees in 1 month</p>       
            </div>
            </div>
        </div>
    </div>
    
</body>
</html>