<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <title>Attendance Monitoring Website</title>

    
    <link rel="stylesheet" href="css/nav.css">

</head>

    <body background="img/PITA.jpg">
        <header>
            <div class="top">
                <a href="index.php"><img src="../img/logo.png" /></a>
                <h2 class="logo">PBAMS</h2>
            </div>
            <div class="nav">
                <ul>
                    <li><a href="about.php" ><mark>about</mark></li>
                    <li><a href="contact.php">Contacts</a></li>
                    <li><a href="../login.php">log&nbsp;out</a></li>
            </div>
        </header><br>
        
            
        <div class="school">
            <a href="index.php"><img src="../img/arrow-left.png"/></a>
            <h1>About</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat perferendis asperiores laudantium necessitatibus! 
                Architecto eos natus harum nisi beatae ratione ad reiciendis excepturi consectetur esse voluptatibus repudiandae, 
                at distinctio cumque!
            </p>
        </div>
    </body>
    </html>