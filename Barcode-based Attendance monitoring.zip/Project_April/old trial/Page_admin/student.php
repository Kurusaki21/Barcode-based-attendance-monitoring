<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring Website</title>
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/Student.css">


</head>

<body> 
    <header>
        <div class="top">
            <a href="#"><img src="../img/logo.png" /></a>
            <h2 class="logo">PBAMS</h2></a>
        </div>
        <div class="nav">
            <ul>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contacts</a></li>
                <li><a href="../login.php">Log&nbsp;out</a></li>
            </ul>
        </div>
    </header>
        <div class="side-menu">
            <div class="brand-name"></div>
                <nav><i><img src="../img/Profile.png"></i>
                    <h2>Admin Name</h2>
                    <p>ADMIN</p> 
            
                <ul>
                    <li><img src="../img/graph.png"><a href="admin_page.php">&nbsp;Dashboard</li></a>
                    <li><img src="../img/group.svg"> <a href="student.php"><u>&nbsp;Students</u></li></a>
                    <li><img src="../img/records.png"><a href="#">&nbsp;Records</li></a>
                    <li><img src="../img/barcode.png"><a href="barcode.php">&nbsp;Barcode</li></a>
                    <li><img src="../img/sms.png"><a href="#">&nbsp;Messages</li> </a>
                </ul>
            </nav>

        <div class="Card">
            <h1>STUDENTS&nbsp;RECORD</h1>
            <div class="department">
                <select name="Department">
                    <option value="department">BSIT</option>
                    <option value="department">BSBA</option>
                    <option value="department">BEE</option>
                    <option value="department">BSEE</option>
                    <option value="department">ACT</option>
                    <option value="department">BSCS</option>
                </select>
        </div>

        <div class="year">
            <select name="Year">
                <option value="year">1st&nbsp;year</option>
                <option value="year">2nd&nbsp;year</option>
                <option value="year">3rd&nbsp;year</option>
                <option value="year">4th&nbsp;year</option>
            </select>
        </div>

        <div class="block">
            <select name="Block">
                <option value="block">A</option>
                <option value="block">B</option>
                <option value="block">C</option>
                <option value="block">D</option>
            </select>
        </div>

        <div class="create">
            <a href="create.php"> <img src="../img/circle-plus.webp"><b>ADD</b></a>
        </div>

        <div class="search">
            <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search for names...">
        </div>

        <table id="studentsTable">
          <tr>
            <th>ID NO</th>
            <th>NAME</th>
            <th>ADDRESS</th>
            <th>PARENT NO</th>
            <th>BARCODE GENERATED</th>
            <th></th>
          </tr>
          <tr>
            <td>001</td>
            <td>Ariel Bonaobra</td>
            <td>Cawayan</td>
            <td>09214192128</td>
            <td>123456789</td>
            <td><button class="button" onclick="editRow(this)">Edit</button></td>
          </tr>
          <tr>
            <td>002</td>
            <td>Christian James Campo</td>
            <td>Bacacay</td>
            <td>09222555100</td>
            <td>987654321</td>
            <td><button class="button" onclick="editRow(this)">Edit</button></td>
          </tr>
          <tr>
            <td>003</td>
            <td>John Paul Pramoso</td>
            <td>San Jose</td>
            <td>0910055222</td>
            <td>456789123</td>
            <td><button class="button" onclick="editRow(this)">Edit</button></td>
          </tr>
          <tr>
            <td>004</td>
            <td>Sherylene Bello</td>
            <td>Moon</td>
            <td>0910055222</td>
            <td>456789123</td>
            <td><button class="button" onclick="editRow(this)">Edit</button></td>
            
          </tr>
        </table>
       
        </div>
    </div>

    <script src="../login/js/student.js"></script>
</body>
</html>