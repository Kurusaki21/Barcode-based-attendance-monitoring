// Get the camera and barcode elements
var camera = document.getElementById('camera');
var barcode_result = document.getElementById('barcode_result');

// Request access to the user's camera
navigator.mediaDevices.getUserMedia({ video: true })
    .then(function (stream) {
        camera.srcObject = stream;
        camera.play();

        // Use the jsQR library to scan the video feed for a QR code
        setInterval(function () {
            var context = camera.getContext('2d');
            var imgData = context.getImageData(0, 0, camera.width, camera.height);
            var qr = jsQR(imgData.data, imgData.width, imgData.height);

            if (qr) {
                // Display the scanned barcode
                barcode_result.innerHTML = barcode.data;

                // Send the barcode to the server
                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'scan.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        // Handle the response from the server
                        var response = JSON.parse(xhr.responseText);
                        if (response.status == 'success') {
                            alert('Barcode found in database');
                        } else {
                            alert('Barcode not found in database');
                        }
                    }
                };
                xhr.send('barcode=' + barcode.data);
            }
        }, 500);
    })
    .catch(function (err) {
        // Handle errors
        console.log(err);
    });