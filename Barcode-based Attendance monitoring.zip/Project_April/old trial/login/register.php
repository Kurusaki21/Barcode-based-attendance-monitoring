<?php

@include 'config.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $user_type = $_POST['user_type'];

   $select = " SELECT * FROM user_form WHERE email = '$email' && password = '$pass' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exist!';

   }else{

      if($pass != $cpass){
         $error[] = 'password not matched!';
      }else{
         $insert = "INSERT INTO user_form(name, email, password, user_type) VALUES('$name','$email','$pass','$user_type')";
         mysqli_query($conn, $insert);
         header('location:login.php');
      }
   }

};


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon"/>
     <link rel="stylesheet" href="css/form.css"/>
</head>
<body>
    <header>
            <a href="index.php"><img src="../../Project/img/logo.png" /></a>
            <h2 class="logo">PBAMS</h2>

        <div class="nav">
            <ul>
                <li><a href="help.php" >HELP</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="more.php">MORE</a></li>
            </ul>
        </div>
    </header>



    <div class="card">
        <p><b>WELCOME!!!</b><br> to Attendance Monitoring System Of Polytechnic Institute of Tabaco.</p>
        
        <form action="" method="post">
            <div class="form">
            <h1 class="heading">SIGN UP</h1>
            <?php
            if(isset($error)){
                foreach($error as $error){
                    echo '<span class="error-msg">'.$error.'</span>';
                };
            };
            ?>
            <input type="text" name="name" required placeholder="enter your name">
            <input type="email" name="email" required placeholder="enter your email">
            <input type="password" name="password" required placeholder="enter your password">
            <input type="password" name="cpassword" required placeholder="confirm your password">
            <select name="user_type">
                <option value="user">user</option>
                <option value="admin">admin</option>
            </select>
            <input type="submit" name="submit" value="Signup" class="submit-btn">
            <a href="login.php" class="link"> <u>already have an account? login here</u></a>
            </div>
        </form>
        </div>
    </div>


    <script src="js/form.js"></script>
</body>
</html>