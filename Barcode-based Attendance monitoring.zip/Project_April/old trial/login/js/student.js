function editRow(button) {
    var row = button.parentNode.parentNode;
    var cells = row.getElementsByTagName("td");
    if (row.className == "editmode") {
      for (var i = 0; i < cells.length - 1; i++) {
var input = cells[i].getElementsByTagName("input")[0];
cells[i].innerHTML = input.value;
}
button.innerHTML = "Edit";
row.className = "";
} else {
for (var i = 0; i < cells.length - 1; i++) {
var text = cells[i].innerHTML;
cells[i].innerHTML = "<input type='text' value='" + text + "'>";
}
button.innerHTML = "Save";
row.className = "editmode";
}
}
function searchTable() {
var input, filter, table, tr, td, i, txtValue;
input = document.getElementById("searchInput");
filter = input.value.toUpperCase();
table = document.getElementById("studentsTable");
tr = table.getElementsByTagName("tr");
for (i = 1; i < tr.length; i++) {
  td = tr[i].getElementsByTagName("td")[1];
  if (td) {
    txtValue = td.textContent || td.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      tr[i].style.display = "";
    } else {
      tr[i].style.display = "none";
    }
  }       
}
}