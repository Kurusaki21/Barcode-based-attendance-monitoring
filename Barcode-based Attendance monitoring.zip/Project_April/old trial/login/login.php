<?php

@include 'config.php';

session_start();

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $user_type = $_POST['user_type'];

   $select = " SELECT * FROM user_form WHERE email = '$email' && password = '$pass' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $row = mysqli_fetch_array($result);

      if($row['user_type'] == 'admin'){

         $_SESSION['admin_name'] = $row['name'];
         header('location:../Page_admin/admin_page.php');

      }elseif($row['user_type'] == 'user'){

         $_SESSION['user_name'] = $row['name'];
         header('location:user_page.php');

      }
     
   }else{
      $error[] = 'incorrect email or password!';
   }

};
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login Page</title>

    <link rel="shortcut icon" href="../../Project/img/logo.png" type="image/x-icon"/>
     <link rel="stylesheet" href="css/form.css"/>
     

</head>

<body background="../img/PITA.jpg"> 

    <header>
                <a href="login.php"><img src="../../Project/img/logo.png" /></a>
                <a href="login.php"><h2 class="logo">PBAMS</h2></a>
        <div class="nav">
            <ul>
                <li><a href="help.php" >HELP</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="more.php">MORE</a></li>
            </ul>
        </div>
    </header>


    </div>
    <div class="card">
        <p><b>WELCOME!!!</b><br> to Attendance Monitoring System Of Polytechnic Institute of Tabaco.</p>
        
        <form action="" method="post">
            <div class="form">
            <h1 class="heading">Log&nbsp;in</h1>
            <?php
            if(isset($error)){
                foreach($error as $error){
                    echo '<span class="error-msg">'.$error.'</span>';
                };
            };
            ?>
            <input type="email" name="email" required placeholder="enter your email">
            <input type="password" name="password" required placeholder="enter your password">
            
            <input type="submit" name="submit" value="login now" class="submit-btn">
            
            <a href="register.php" class="link"> <u>don't have an account? Signup</u></a>
            </div>
        </form> 
    </div>

    <script src="js/form.js"></script>


<footer><h6>&copy;Copyright Reserve </h6>
</body>
</html>