<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <title>Attendance Monitoring Website</title>
    
    
    <link rel="stylesheet" href="css/form.css">
    <link rel="stylesheet" href="css/more.css">

</head>


    <body background="../img/PITA.jpg">
        <header>
            <a href="login.php"><img src="../img/logo.png" /></a>
            <h2 class="logo">PBAMS</h2>
            <div class="nav">
                <ul>
                    <li><a href="help.php" >HELP</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="more.php"><mark>MORE</mark></a></li>
            </div>
        </header><br>
        
            
        <div class="more">
            <a href="login.php"><img src="../img/arrow-left.png"/></a>
            <h1>MORE</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat perferendis asperiores laudantium necessitatibus! 
                Architecto eos natus harum nisi <br><br> ratione ad reiciendis excepturi consectetur esse voluptatibus repudiandae, 
                at distinctio cumque!
            </p>
        </div>
    </body>
    </html>