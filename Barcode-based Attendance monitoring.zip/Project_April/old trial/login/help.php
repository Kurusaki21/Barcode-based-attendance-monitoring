

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <title>Attendance Monitoring Website</title>
    
    
    <link rel="stylesheet" href="css/form.css">
    <link rel="stylesheet" href="css/help.css">

</head>


    <body background="../img/PITA.jpg">
        <header>
            <a href="login.php"><img src="../img/logo.png" /></a>
            <h2 class="logo">PBAMS</h2>
            <div class="nav">
                <ul>
                    <li><a href="help.php" ><mark>HELP</mark></a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="more.php">MORE</a></li>
            </div>
        </header><br>
              
        <div class="help">
            <a href="login.php"><img src="../img/arrow-left.png"/></a>
            <h1>HELP</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat perferendis asperiores laudantium necessitatibus! <br><br>
                Architecto eos natus harum nisi beatae ratione ad reiciendis excepturi consectetur esse voluptatibus repudiandae, 
                at distinctio cumque!
            </p>
        </div>
    </body>
    </html>