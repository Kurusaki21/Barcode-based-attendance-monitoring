<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
        header('location:login.php');
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin_Page</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        
        <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon"/>
        <link rel="stylesheet" href="css/index.css">
</head> 
<body>
        <!--top navigation-->
        <img class="bg-img" src="../img/PITA.jpg" alt="Bg image">
        <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid">
                        <a class="navbar-brand" href="#"><img src="../img/logo.png">PBAMS</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navContent" 
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navContent">
                        <ul class="navbar-nav ms-auto mb-lg-0">
                                <li class="nav-item">
                                        <a class="nav-link" href="#">About</a>
                                </li>
                                <li class="nav-item">
                                        <a class="nav-link" href="#">Contacts</a>
                                </li>
                                <li class="nav-item">
                                        <a class="nav-link" href="#">logout</a>
                                </li>
                        </ul>
                        </div>
                </div>
        </nav>
        <div class="container-fluid">
                <div class="row">
                        <!-- Sidebar -->
                        <div class="col-lg-3 col-md-4 col-sm-12 sidebar">
                                <div class="profile-picture">
                                <img src="../img/Profile.png" alt="Profile picture">
                                </div>
                                <div class="admin-name">
                                Roy Balana
                                <br>
                                <small>Administrator</small>
                                </div>
                                <div class="menu list-group">
                                <a href="#" class="list-group-item list-group-item-action list-group-item-dark"><img  src="../img/graph.png" > &nbsp;Dashboard</a>
                                <a href="#"><img  src="../img/group.svg" >&nbsp;Students</a>
                                <a href="#"><img  src="../img/records.png" >&nbsp;History</a>
                                <a href="#"><img  src="../img/barcode.png">&nbsp;Barcode</a>
                                <a href="#"><img  src="../img/sms.png" >&nbsp;Message</a>
                                </div>
                        </div>
                </div>
        </div>
</body>
</html>
